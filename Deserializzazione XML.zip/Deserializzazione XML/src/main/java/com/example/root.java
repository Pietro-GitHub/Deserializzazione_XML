package com.example;

public class root {
    private int annoDiInizio;
    private String classe;
    private int numeroFinestre;
    private String specializzazione;
    private Aula aula;
    private Studenti studenti[];

    //costruttore di default
    public root(){
    }
    
    public int getAnnoDiInizio() {
        return annoDiInizio;
    }
    public Studenti[] getStudenti() {
        return studenti;
    }
    public void setStudenti(Studenti studenti[]) {
        this.studenti = studenti;
    }
    public Aula getAula() {
        return aula;
    }
    public void setAula(Aula aula) {
        this.aula = aula;
    }
    public String getSpecializzazione() {
        return specializzazione;
    }
    public void setSpecializzazione(String specializzazione) {
        this.specializzazione = specializzazione;
    }
    public int getNumeroFinestre() {
        return numeroFinestre;
    }
    public void setNumeroFinestre(int numeroFinestre) {
        this.numeroFinestre = numeroFinestre;
    }
    public String getClasse() {
        return classe;
    }
    public void setClasse(String classe) {
        this.classe = classe;
    }
    public void setAnnoDiInizio(int annoDiInizio) {
        this.annoDiInizio = annoDiInizio;
    }
}
